<h3>How to use:</h3>

<p>[include]myfile.php[/include]</p>

<p>Included file can contain PHP, HTML or both</p>

<p><img src="<?php echo WP_PLUGIN_URL.'/keithics_include/'; ?>example.jpg" /></p>